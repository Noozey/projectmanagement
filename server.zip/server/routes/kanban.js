import express from "express";
import { supabase } from "../database/supabaseConfig.js";
import { authMiddleware } from "../middleware/authMiddleware.js";
import { authorize } from "../middleware/roleMiddleware.js";

const kanbanRouter = express.Router();

const broadcast = (req, projectId, event, data) => {
  const io = req.app.get("socketio");
  if (io && projectId) {
    io.to(projectId).emit(event, data);
  }
};

kanbanRouter.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const { data: columns, error: columnsError } = await supabase
      .from("kanban_columns")
      .select("*")
      .eq("project_id", id)
      .order("position", { ascending: true });

    if (columnsError) throw columnsError;

    const { data: tasks, error: tasksError } = await supabase
      .from("kanban_tasks")
      .select(
        `
        *,
        kanban_task_mentions (
          user_id,
          registration (uid, name)
        )
      `,
      )
      .in("column_id", columns?.map((c) => c.id) || [])
      .order("position", { ascending: true });

    if (tasksError) throw tasksError;

    const formattedColumns = columns?.reduce((acc, col) => {
      const columnTasks = tasks?.filter((t) => t.column_id === col.id) || [];
      acc[col.id] = {
        name: col.name,
        tasks: columnTasks.map((task) => ({
          id: task.id,
          title: task.title,
          description: task.description,
          mentions: task.kanban_task_mentions?.map((m) => m.user_id) || [],
        })),
      };
      return acc;
    }, {});

    res.json(formattedColumns || {});
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch kanban data" });
  }
});

kanbanRouter.get("/:id/members", async (req, res) => {
  try {
    const { data: project, error } = await supabase
      .from("projects")
      .select("users")
      .eq("uid", req.params.id)
      .single();

    if (error) throw error;

    const uniqueUsers = [
      ...new Map((project?.users || []).map((u) => [u.uid, u])).values(),
    ];

    const uids = uniqueUsers.map((u) => u.uid);

    const { data: registrations, error: regError } = await supabase
      .from("registration")
      .select("uid, name")
      .in("uid", uids);

    if (regError) throw regError;

    const nameMap = new Map(registrations.map((r) => [r.uid, r.name]));

    res.json(
      uniqueUsers.map(({ uid }) => ({
        id: uid,
        uid,
        name: nameMap.get(uid) || "Unknown",
        initial: (nameMap.get(uid)?.charAt(0) || "?").toUpperCase(),
      })),
    );
  } catch {
    res.status(500).json({ error: "Failed to fetch members" });
  }
});

kanbanRouter.post(
  "/:id/columns",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { name } = req.body;

      const { data: existing } = await supabase
        .from("kanban_columns")
        .select("position")
        .eq("project_id", id)
        .order("position", { ascending: false })
        .limit(1);

      const newPosition = existing?.[0]?.position + 1 || 0;

      const { data, error } = await supabase
        .from("kanban_columns")
        .insert({ project_id: id, name, position: newPosition })
        .select()
        .single();

      if (error) throw error;

      broadcast(req, id, "kanban_column_created", {
        id: data.id,
        name: data.name,
        tasks: [],
      });

      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to create column" });
    }
  },
);

kanbanRouter.delete(
  "/:id/columns/:columnId",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id, columnId } = req.params;
      const { error } = await supabase
        .from("kanban_columns")
        .delete()
        .eq("id", columnId);
      if (error) throw error;

      broadcast(req, id, "kanban_column_deleted", { columnId });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete column" });
    }
  },
);

kanbanRouter.post(
  "/:id/tasks",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id } = req.params;
      const { columnId, title, description, mentions } = req.body;

      const { data: existing } = await supabase
        .from("kanban_tasks")
        .select("position")
        .eq("column_id", columnId)
        .order("position", { ascending: false })
        .limit(1);

      const newPosition = existing?.[0]?.position + 1 || 0;

      const { data: task, error: taskError } = await supabase
        .from("kanban_tasks")
        .insert({
          column_id: columnId,
          project_id: id,
          title,
          description,
          position: newPosition,
        })
        .select()
        .single();

      if (taskError) throw taskError;

      // Handle Mentions
      if (mentions?.length > 0) {
        const inserts = mentions.map((uId) => ({
          task_id: task.id,
          user_id: uId,
        }));
        await supabase.from("kanban_task_mentions").insert(inserts);
      }

      broadcast(req, id, "kanban_task_created", {
        ...task,
        mentions: mentions || [],
      });

      res.json({ ...task, mentions: mentions || [] });
    } catch (error) {
      res.status(500).json({ error: "Failed to create task" });
    }
  },
);

kanbanRouter.put(
  "/:id/tasks/:taskId",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id, taskId } = req.params;
      const { title, description, mentions } = req.body;

      const { data: task, error: taskError } = await supabase
        .from("kanban_tasks")
        .update({ title, description, updated_at: new Date().toISOString() })
        .eq("id", taskId)
        .select()
        .single();

      if (taskError) throw taskError;

      await supabase
        .from("kanban_task_mentions")
        .delete()
        .eq("task_id", taskId);
      if (mentions?.length > 0) {
        const inserts = mentions.map((uId) => ({
          task_id: taskId,
          user_id: uId,
        }));
        await supabase.from("kanban_task_mentions").insert(inserts);
      }

      broadcast(req, id, "kanban_task_updated", {
        ...task,
        mentions: mentions || [],
      });

      res.json({ ...task, mentions: mentions || [] });
    } catch (error) {
      res.status(500).json({ error: "Failed to update task" });
    }
  },
);

kanbanRouter.delete(
  "/:id/tasks/:taskId",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id, taskId } = req.params;
      const { error } = await supabase
        .from("kanban_tasks")
        .delete()
        .eq("id", taskId);
      if (error) throw error;

      broadcast(req, id, "kanban_task_deleted", { taskId });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  },
);

kanbanRouter.put(
  "/:id/tasks/:taskId/move",
  authMiddleware,
  authorize(["Admin", "Super", "Editor"]),
  async (req, res) => {
    try {
      const { id, taskId } = req.params;
      const { targetColumnId } = req.body;

      const { data: existing } = await supabase
        .from("kanban_tasks")
        .select("position")
        .eq("column_id", targetColumnId)
        .order("position", { ascending: false })
        .limit(1);

      const newPosition = existing?.[0]?.position + 1 || 0;

      const { data: task, error } = await supabase
        .from("kanban_tasks")
        .update({
          column_id: targetColumnId,
          position: newPosition,
          updated_at: new Date().toISOString(),
        })
        .eq("id", taskId)
        .select()
        .single();

      if (error) throw error;

      const { data: currentMentions } = await supabase
        .from("kanban_task_mentions")
        .select("user_id")
        .eq("task_id", taskId);

      const mentionsArr = currentMentions?.map((m) => m.user_id) || [];

      broadcast(req, id, "kanban_task_updated", {
        ...task,
        mentions: mentionsArr,
      });

      res.json(task);
    } catch (error) {
      res.status(500).json({ error: "Failed to move task" });
    }
  },
);

export { kanbanRouter };
